
import os
import subprocess
import time
import tkinter as tk
from tkinter import messagebox, ttk
from datetime import datetime

LOG_FILE = os.path.join(os.getcwd(), "cs2_optimizer_log.txt")

def log_action(action):
    with open(LOG_FILE, "a") as f:
        f.write(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] {action}\n")

def toggle_game_mode(enable=True):
    val = 1 if enable else 0
    try:
        subprocess.run(f'reg add "HKCU\\Software\\Microsoft\\GameBar" /v AutoGameModeEnabled /t REG_DWORD /d {val} /f', shell=True)
        log_action(f"Game Mode {'enabled' if enable else 'disabled'}")
    except Exception as e:
        log_action(f"Failed to toggle Game Mode: {str(e)}")

def set_bitsum_power_plan():
    try:
        result = subprocess.check_output('powercfg /list', shell=True).decode()
        if "Bitsum Highest Performance" in result:
            for line in result.splitlines():
                if "Bitsum Highest Performance" in line:
                    guid = line.strip().split(":")[1].split("(")[0].strip()
                    subprocess.run(f'powercfg -setactive {guid}', shell=True)
                    log_action("Power plan set to Bitsum Highest Performance")
                    return
        else:
            subprocess.run("powercfg -setactive SCHEME_MIN", shell=True)
            log_action("Bitsum plan not found. Fallback to High Performance.")
    except Exception as e:
        log_action(f"Failed to set power plan: {str(e)}")

def disable_services():
    services = [
        "SysMain", "WSearch", "DiagTrack", "BITS", 
        "PrintSpooler", "Fax", "RemoteRegistry", "Bluetooth Support Service"
    ]
    for service in services:
        try:
            subprocess.run(f'sc stop "{service}"', shell=True)
            subprocess.run(f'sc config "{service}" start= disabled', shell=True)
            log_action(f"Disabled service: {service}")
        except Exception as e:
            log_action(f"Failed to disable service {service}: {str(e)}")

def restore_defaults():
    try:
        subprocess.run('powercfg -setactive SCHEME_BALANCED', shell=True)
        subprocess.run(f'reg add "HKCU\\Software\\Microsoft\\GameBar" /v AutoGameModeEnabled /t REG_DWORD /d 0 /f', shell=True)
        services = [
            "SysMain", "WSearch", "DiagTrack", "BITS", 
            "PrintSpooler", "Fax", "RemoteRegistry", "Bluetooth Support Service"
        ]
        for service in services:
            subprocess.run(f'sc config "{service}" start= auto', shell=True)
            subprocess.run(f'sc start "{service}"', shell=True)
        subprocess.run("taskkill /f /im explorer.exe", shell=True)
        time.sleep(2)
        subprocess.run("start explorer.exe", shell=True)
        log_action("Restored defaults and restarted explorer.exe")
        messagebox.showinfo("LiveOn3", "Windows settings restored to default.")
    except Exception as e:
        log_action(f"Failed to restore defaults: {str(e)}")

def apply_optimization():
    toggle_game_mode(True)
    set_bitsum_power_plan()
    disable_services()
    subprocess.run("taskkill /f /im explorer.exe", shell=True)
    time.sleep(2)
    subprocess.run("start explorer.exe", shell=True)
    log_action("Applied competitive tweaks and restarted explorer.exe")
    messagebox.showinfo("LiveOn3", "Competitive Mode Enabled. Optimizations applied.")

# GUI Setup
root = tk.Tk()
root.title("LiveOn3 Optimizer")
root.geometry("400x300")

title = ttk.Label(root, text="LiveOn3 Competitive Optimizer", font=("Segoe UI", 14))
title.pack(pady=10)

tooltip = ttk.Label(root, text="• Enables Game Mode & Bitsum Power Plan\n• Disables background services\n• Restore to Windows defaults anytime", wraplength=350, foreground="gray")
tooltip.pack(pady=5)

optimize_btn = ttk.Button(root, text="Enable Competitive Mode", command=apply_optimization)
optimize_btn.pack(pady=15)

restore_btn = ttk.Button(root, text="Restore Windows Defaults", command=restore_defaults)
restore_btn.pack(pady=5)

exit_btn = ttk.Button(root, text="Exit", command=root.destroy)
exit_btn.pack(pady=10)

root.mainloop()
